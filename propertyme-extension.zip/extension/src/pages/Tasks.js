const Tasks = () => {
  return (
    <div className="App">
      Tasks
    </div>
  );
};

export default Tasks;
