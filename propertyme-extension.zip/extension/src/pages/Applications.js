const Applications = () => {
  return (
    <div className="App">
      Applications
    </div>
  );
};

export default Applications;
