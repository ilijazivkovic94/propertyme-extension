const Rentals = () => {
  return (
    <div className="App">
      Rentals
    </div>
  );
};

export default Rentals;
